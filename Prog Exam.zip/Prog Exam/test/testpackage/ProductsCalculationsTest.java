/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */




package testpackage;

import newpackage.IProductsCalculations;
import newpackage.ProductsCalculations;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductsCalculationsTest {

    private IProductsCalculations calc;

    @BeforeEach
    void setUp() {
        calc = new ProductsCalculations(1000.00);
    }

    @Test
    void GetVat_WithValidData_ReturnsCorrectValue() {
        // 15% of 1000.00
        assertEquals(150.00, calc.GetVat(), 0.001);
    }

    @Test
    void GetTotal_WithValidData_ReturnsCorrectValue() {
        // 1000.00 + 150.00 VAT + 50.00 commission
        assertEquals(1200.00, calc.GetTotal(), 0.001);
    }
}