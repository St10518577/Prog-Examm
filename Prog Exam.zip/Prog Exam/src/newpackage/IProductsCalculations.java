package newpackage;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Sibiy
 */


public interface IProductsCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}
