/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Sibiy
 */



 
    

public abstract class Product implements Iproducts {
    private final String[] names;   // single-dimensional
    private final int[][] sales;    // [product][month]

    public Product(String[] names, int[][] sales) {
        this.names = names;
        this.sales = sales;
    }

    private int totalFor(int p) {
        int t = 0;
        for (int m : sales[p]) t += m;
        return t;
    }

    public int GetTotalProductsSold() {
        int t = 0;
        for (int p = 0; p < sales.length; p++) t += totalFor(p);
        return t;
    }

    @Override
    public double GetAverageProductSold() {
        return GetTotalProductsSold() / (double) (sales.length * sales[0].length);
    }

    public String GetMostPopularProduct() {
        int best = 0;
        for (int p = 1; p < sales.length; p++)
            if (totalFor(p) > totalFor(best)) best = p;
        return names[best] + " (" + totalFor(best) + ")";
    }
}